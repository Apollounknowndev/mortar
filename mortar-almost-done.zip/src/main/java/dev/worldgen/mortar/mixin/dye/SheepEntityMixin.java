package dev.worldgen.mortar.mixin.dye;

import dev.worldgen.mortar.misc.MortarAttachments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.util.DyeColor;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(SheepEntity.class)
public abstract class SheepEntityMixin extends Entity {
    public SheepEntityMixin(EntityType<?> type, World world) {
        super(type, world);
    }

    /**
     * @author Apollo
     * @reason Unconditional override of getColor to use data attachments.
     */
    @Overwrite
    public DyeColor getColor() {
        return this.getAttachedOrElse(MortarAttachments.COLOR, DyeColor.WHITE);
    }

    /**
     * @author Apollo
     * @reason Unconditional override of setColor to use data attachments.
     */
    @Overwrite
    public void setColor(DyeColor color) {
        this.setAttached(MortarAttachments.COLOR, color);
    }

    /**
     * @author Apollo
     * @reason Unconditional override of isSheared to use data attachments.
     */
    @Overwrite
    public boolean isSheared() {
        return this.getAttachedOrElse(MortarAttachments.SHEARED, false);
    }

    /**
     * @author Apollo
     * @reason Unconditional override of setSheared to use data attachments.
     */
    @Overwrite
    public void setSheared(boolean sheared) {
        this.setAttached(MortarAttachments.SHEARED, sheared);
    }
}
